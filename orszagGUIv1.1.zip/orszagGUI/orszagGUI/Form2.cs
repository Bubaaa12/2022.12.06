﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace orszagGUI
{
    public partial class Form2 : Form
    {
        public Form2(string feladat,string megoldas)
        {
            string query = megoldas;
            string connStr = "server=localhost;user=root;port=3306;password=;database=foldrajz";
            MySqlConnection con = new MySqlConnection(connStr);
            MySqlCommand cmd = new MySqlCommand(query, con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            InitializeComponent();
            richTextBox1.Text = feladat;
            for (int i = 0; reader.Read(); i++)
            {
                richTextBox1.Text += reader[i].ToString();
            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
            
        }


    }
}
