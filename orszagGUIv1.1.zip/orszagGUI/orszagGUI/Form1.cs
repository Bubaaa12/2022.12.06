﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace orszagGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            for (int i = 1; i < 65; i++)
            {
                listBox1.Items.Add(i.ToString());
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            string[] array = File.ReadAllLines("feladatok.txt");
            Form2 form2 = new Form2(array[index + 1], array[index+2]);
            this.Hide();
            form2.Show();
        }
    }
}
